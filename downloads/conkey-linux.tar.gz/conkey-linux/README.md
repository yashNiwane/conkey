# ConKey for Linux

Turn your mobile phone into an ultra-low-latency wireless keyboard, trackpad, and system-wide live voice dictation remote for your Linux desktop or laptop.

## Features
- **Precision Keyboard & Modifiers**: Send keystrokes, Ctrl/Alt/Super shortcuts, Function keys (F1-F12), and text.
- **Multi-Touch Trackpad**: Relative mouse movement, tap-to-click, right-click, and smooth scrolling.
- **System-Wide Live Voice Typing**: Phonon-2 streaming speech-to-text directly types into whichever active window has keyboard focus (browsers, text editors, terminal, IDEs).
- **Dual Display Protocol**: Web client + native Android app with automatic LAN mDNS/UDP discovery.

## Requirements
- Python 3.9+ with `tkinter` (usually installed via `sudo apt install python3-tk` on Debian/Ubuntu or `sudo dnf install python3-tkinter` on Fedora).
- For keyboard/mouse input:
  - **X11**: `xdotool` (`sudo apt install xdotool` or `sudo dnf install xdotool`).
  - **Wayland / Kernel uinput**: Linux `/dev/uinput` support is built-in. Make sure your user is in the `input` group:
    ```bash
    sudo usermod -aG input $USER
    ```

## Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Directly
```bash
chmod +x conkey
./conkey
```

### 3. Install to Desktop Menu (Optional)
```bash
chmod +x install.sh
./install.sh
```
This installs ConKey into `~/.local/share/conkey`, places a launcher in `~/.local/bin/conkey`, and adds an application menu shortcut (`conkey.desktop`).

## Configuration
Host settings (PIN, port, device name) are stored in `config.json`.
Default server port is `8765`.
