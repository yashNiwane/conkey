#!/usr/bin/env bash
set -e

# ==============================================================================
# ConKey Linux Installer
# Installs ConKey to ~/.local/share/conkey, creates launcher in ~/.local/bin/conkey,
# and integrates desktop icon & menu entry in ~/.local/share/applications/
# ==============================================================================

echo "=========================================="
echo "    ConKey Desktop Installer for Linux    "
echo "=========================================="

INSTALL_DIR="$HOME/.local/share/conkey"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"
ICON_DIR="$HOME/.local/share/icons/hicolor/scalable/apps"

mkdir -p "$INSTALL_DIR"
mkdir -p "$BIN_DIR"
mkdir -p "$DESKTOP_DIR"
mkdir -p "$ICON_DIR"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[1/4] Copying ConKey files to $INSTALL_DIR..."
rm -rf "$INSTALL_DIR/host"
cp -r "$SCRIPT_DIR/host" "$INSTALL_DIR/"
if [ -f "$SCRIPT_DIR/config.json" ] && [ ! -f "$INSTALL_DIR/config.json" ]; then
    cp "$SCRIPT_DIR/config.json" "$INSTALL_DIR/"
fi

echo "[2/4] Installing application icon..."
if [ -f "$SCRIPT_DIR/conkey.svg" ]; then
    cp "$SCRIPT_DIR/conkey.svg" "$ICON_DIR/conkey.svg"
fi

echo "[3/4] Creating terminal launcher ($BIN_DIR/conkey)..."
cat << 'EOF' > "$BIN_DIR/conkey"
#!/usr/bin/env bash
APP_DIR="$HOME/.local/share/conkey"
export PYTHONPATH="$APP_DIR:$PYTHONPATH"
exec python3 -m host.desktop_app "$@"
EOF
chmod +x "$BIN_DIR/conkey"

echo "[4/4] Creating desktop entry ($DESKTOP_DIR/conkey.desktop)..."
cat << EOF > "$DESKTOP_DIR/conkey.desktop"
[Desktop Entry]
Name=ConKey
GenericName=Remote Keyboard & Touchpad
Comment=Wireless Keyboard, Touchpad & System-Wide Live Voice Remote
Exec=$BIN_DIR/conkey
Icon=conkey
Terminal=false
Type=Application
Categories=Utility;InputMethod;HardwareSettings;
Keywords=keyboard;touchpad;remote;voice;dictation;
StartupNotify=true
EOF
chmod +x "$DESKTOP_DIR/conkey.desktop"

# Check if ~/.local/bin is in PATH
if [[ ":$PATH:" != *":$BIN_DIR:"* ]]; then
    echo ""
    echo "Note: $BIN_DIR is not in your PATH."
    echo "Add this to your ~/.bashrc or ~/.zshrc:"
    echo '  export PATH="$HOME/.local/bin:$PATH"'
fi

# Verify input permissions
echo ""
echo "Input System Verification:"
if command -v xdotool &> /dev/null; then
    echo "  [OK] xdotool detected for X11 keyboard/mouse injection."
else
    echo "  [INFO] xdotool not detected. If on X11, install it via: sudo apt install xdotool"
fi

if [ -w /dev/uinput ]; then
    echo "  [OK] /dev/uinput is writable (Wayland & X11 kernel input supported)."
else
    echo "  [INFO] /dev/uinput is not writable by current user."
    echo "  To enable uinput kernel-level input on Wayland, run:"
    echo "    sudo usermod -aG input \$USER"
fi

echo ""
echo "Installation complete!"
echo "Launch ConKey by running 'conkey' or clicking the ConKey icon in your application launcher."
