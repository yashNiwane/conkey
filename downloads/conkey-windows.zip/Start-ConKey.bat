@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title ConKey Desktop Launcher

if exist "ConKey.exe" (
    start "" "ConKey.exe"
    exit /b 0
)

echo ConKey binary not found in current folder, falling back to python...
where python >nul 2>&1
if %ERRORLEVEL% equ 0 (
    start "" python host\desktop_app.py
    exit /b 0
)

echo [ERROR] Python 3 was not found on your system.
echo Please run ConKey.exe or install Python 3.9+ from https://www.python.org/
pause
