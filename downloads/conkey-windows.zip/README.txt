========================================================================
                      ConKey Desktop for Windows
    Wireless Keyboard, Multi-Touch Trackpad & System-Wide Live Voice Typing
========================================================================

QUICK START:
1. Double-click "ConKey.exe" (or "Start-ConKey.bat").
2. The ConKey Desktop Dashboard will open and show:
   - Your local Wi-Fi / LAN IP and Server Port (default 8765)
   - Your 4-digit pairing PIN
   - Phonon-2 speech engine status
3. On your mobile phone, open the browser to http://<IP>:8765 or launch
   the ConKey Android app.
4. Enter the 4-digit PIN to connect.

SYSTEM-WIDE LIVE VOICE TYPING:
- Click the "Dictate" button (with the waveform icon) on your phone.
- Speak naturally: words are transcribed with sub-second latency by the
  on-device Phonon-2 engine and typed directly into whichever application
  has focus (Notepad, Word, browser search bar, Slack, VS Code, etc.).

AUTO-START:
- Inside the desktop dashboard, toggle "Start on Boot" to have ConKey
  run silently in the background when Windows starts.

SUPPORT & ISSUES:
- Settings are saved in config.json.
========================================================================
